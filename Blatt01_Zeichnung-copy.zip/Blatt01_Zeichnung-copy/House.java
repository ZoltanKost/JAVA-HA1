
/**
 * Write a description of class House here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class House
{
    // instance variables - replace the example below with your own
    private int posX;
    private int posY;
    private int scale;
    
    private Dreieck dach;
    private Quadrat wand;
    private Quadrat fenster;
        
    /**
     * Constructor for objects of class Figure
     */
    public House(int _posX, int _posY, int size)
    {
        posX = _posX;
        posY = _posY;
        scale = size;
        dach = new Dreieck(size, size, _posX + size / 2, _posY - size, "gruen");
        wand = new Quadrat(size, _posX, _posY, "rot");
        fenster = new Quadrat(size/6, _posX + size / 2,_posY + size / 2, "gelb");
        DrawHouse();
    }
    
    public void DrawHouse()
    {
        dach.sichtbarMachen();
        wand.sichtbarMachen();
        fenster.sichtbarMachen();
    }
}