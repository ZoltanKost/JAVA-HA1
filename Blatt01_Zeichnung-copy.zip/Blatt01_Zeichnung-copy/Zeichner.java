
/**
 * Exemplare dieser Klasse zeichnen eine einfache Zeichnung.
 * Um die Zeichnung auf dem Bildschirm anzuzeigen, muss die
 * Methode zeichne an einem Exemplar aufgerufen werden.
 *
 * Diese Klasse ist als frühes Java-Lehrbeispiel mit BlueJ gedacht.
 * 
 * @author Axel Schmolitzky
 * @version 2025
 */
class Zeichner
{
    String colorsName;
    /**
     * Zeichne die Zeichnung.
     * 
     * @param color
     *        color's name.
     */
    public void zeichne(String color)
    {
        colorsName = color;

        DrawDach();
        DrawSun();
        DrawWand(color);
        DrawFenster();
    }
    
    public void zeichneHaeuser()
    {
        DrawSun();
        
        House house = new House(120,120, 50);
        
        House h1 = new House(70,20, 50);
        
        House h2 = new House(50,80, 50);
    }
    
    
    public void DrawDach()
    {
        Dreieck dach = new Dreieck();  
        dach.sichtbarMachen();
        dach.groesseAendern(50, 140);
        dach.horizontalBewegen(60);
        dach.vertikalBewegen(70);
    }
    
    public void DrawSun()
    {
        Kreis sonne = new Kreis();
        sonne.sichtbarMachen();
        sonne.farbeAendern("rot");
        sonne.horizontalBewegen(180);
        sonne.vertikalBewegen(-10);
        sonne.groesseAendern(60);
    }
    
    public void DrawFenster()
    {
        Kreis fenster = new Kreis();
        fenster.sichtbarMachen();
        fenster.farbeAendern("rot");
        fenster.horizontalBewegen(50);
        fenster.vertikalBewegen(90);
    }
    
    public void DrawWand(String color)
    {
        Quadrat wand = new Quadrat();
        wand.sichtbarMachen();
        wand.farbeAendern(colorsName);
        wand.vertikalBewegen(80);
        wand.groesseAendern(100);
    }
}
