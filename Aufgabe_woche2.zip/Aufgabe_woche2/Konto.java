
/**
 * Eine Klasse, die ein sehr einfaches Modell von Girokonten implementiert.
 *
 * @author Mihail Costenco
 * @version 04.11.2025
 */
public class Konto
{
    // instance variables - replace the example below with your own
    private int _saldo;
    private int _maxKontoZustand;
    private int _dispo;
    private final int _kontoNummer;

    /**
     * Constructor for objects of class Konto
     * @param Max_KontoZustand maximaler Zustand, der nicht ueberschnnittet 
     * werden soll.
     * @param Nummer einmalig eingegebene Kontonummer. (Konstante)
     */
    public Konto(int Max_KontoZustand, int Nummer, int Dispo)
    {
        _kontoNummer = Nummer;
        _saldo = 10;
        _maxKontoZustand = Max_KontoZustand;
        _dispo = Dispo;
    }

    /**
     * Zahle eine Summe auf das Konto ein. 
     * Returns false, wenn saldo ist mehr 
     * als maxilal moeglicher betrag. 
     * Returns true if einzahlung ist erfolgreich abgeschlossen.
     * @param summe der einzuzahlende Summe
     */
    public boolean einzahlen(int summe)
    {
        if((_saldo + summe) >= _maxKontoZustand)
        {
            return false;
        }
        _saldo += summe;
        return true;
    }
    
    /**
     * Hebe eine Summe auf das Konto ab.
     * Returns true wenn erfolgreich abgezogen.
     * Returns false wenn saldo ist weniger als dispo.
     * @param summe der abzuhebende Summe
     */
    public boolean abheben(int summe)
    {
        int resultSaldo = _saldo - summe;
        if(resultSaldo < 0 && -resultSaldo > _dispo)
        {
            return false;
        }
        _saldo = resultSaldo;
        return true;
    }
    public void setDispo(int Dispo)
    {
        _dispo = Dispo;
    }
    /**
     * Returns kontozustand 
     */
    public int abfragen()
    {
        return _saldo;
    }
    /**
     * Returns Kontonummer (konstant)
     */
    public int getNummer()
    {
        return _kontoNummer;
    }
}